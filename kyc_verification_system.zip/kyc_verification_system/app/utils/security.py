"""
Encrypted-at-rest document storage.

Uploaded files (ID documents, selfies) are encrypted with Fernet (AES-128-CBC +
HMAC) before being written to disk, so a filesystem or backup leak does not
expose raw identity documents.
"""
import hashlib
import os
import uuid

from cryptography.fernet import Fernet

from app.config import settings

_fernet = Fernet(settings.document_encryption_key.encode())

os.makedirs(settings.storage_dir, exist_ok=True)


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encrypt_and_store(raw_bytes: bytes, prefix: str) -> str:
    """Encrypts raw_bytes and writes to storage_dir. Returns the file path."""
    token = _fernet.encrypt(raw_bytes)
    filename = f"{prefix}_{uuid.uuid4().hex}.enc"
    path = os.path.join(settings.storage_dir, filename)
    with open(path, "wb") as f:
        f.write(token)
    return path


def decrypt_file(path: str) -> bytes:
    """Reads an encrypted file from disk and returns the decrypted bytes."""
    with open(path, "rb") as f:
        token = f.read()
    return _fernet.decrypt(token)

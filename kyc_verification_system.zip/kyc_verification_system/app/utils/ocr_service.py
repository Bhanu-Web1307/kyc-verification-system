"""
OCR-based data extraction from uploaded ID document images.

Uses OpenCV for preprocessing (grayscale, thresholding, denoising) to improve
Tesseract's accuracy on photographed/scanned ID documents, then applies simple
regex heuristics to pull out common ID fields.
"""
import io
import json
import re

import cv2
import numpy as np
import pytesseract
from PIL import Image


def _preprocess(image_bytes: bytes) -> np.ndarray:
    image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    img = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    denoised = cv2.fastNlMeansDenoising(gray, h=15)
    # Adaptive threshold handles uneven lighting on photographed documents
    thresh = cv2.adaptiveThreshold(
        denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 11
    )
    return thresh


def extract_text(image_bytes: bytes) -> str:
    processed = _preprocess(image_bytes)
    return pytesseract.image_to_string(processed)


def extract_fields(image_bytes: bytes) -> str:
    """
    Runs OCR and extracts common ID document fields via regex heuristics.
    Returns a JSON string suitable for storing in KYCSubmission.extracted_data.
    """
    raw_text = extract_text(image_bytes)

    fields = {
        "raw_text_preview": raw_text.strip()[:500],
        "name": None,
        "dob": None,
        "id_number": None,
    }

    dob_match = re.search(r"(\d{2}[/-]\d{2}[/-]\d{4})", raw_text)
    if dob_match:
        fields["dob"] = dob_match.group(1)

    id_match = re.search(r"\b([A-Z]{2,5}[0-9]{6,12})\b", raw_text)
    if id_match:
        fields["id_number"] = id_match.group(1)

    name_match = re.search(r"(?:name)[:\s]+([A-Za-z\s]{3,40})", raw_text, re.IGNORECASE)
    if name_match:
        fields["name"] = name_match.group(1).strip()

    return json.dumps(fields)
